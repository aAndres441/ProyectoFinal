export default{
    database: {
        host: 'localhost',  //'localhost',  //aa1v5oaurv6oyc5.cjhnbwblq7zm.us-east-2.rds.amazonaws.com
        user: 'root',  //'root',BarracaCardona
        password: '', //'',  // BarracaCardona
        database:  'barracadb'  //ebdb // 'barracadb'   //  'ng_prueba_db
    }
}