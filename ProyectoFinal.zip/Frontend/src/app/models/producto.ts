export class Producto {
    
    public id : number;
    public nombre : string;
    public imagen? : string;
    public descripcion? : string;
    public tmstmp? : Date;
    public precio? : number;

    constructor(){

    }
}